import React from 'react'
import logo from '../../img/logo.png'
import './Header.css'


function Header() {
    return (
        <>
            <nav className="navbar navbar-expand-lg header">
                <div className="container">
                    <a className="navbar-brand" href="/">
                        <img src={logo} alt="CodeLogicX" />
                    </a>
                    <button className="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                        <span className="navbar-toggler-icon"></span>
                    </button>
                    <div className="collapse navbar-collapse" id="navbarSupportedContent">
                        <ul className="navbar-nav mx-auto mb-2 mb-lg-0">
                        <li class="nav-item dropdown me-3">
                            <a class="nav-link dropdown-toggle" href="/" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Technologies
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="#">Action</a></li>
                                <li><a class="dropdown-item" href="#">Another action</a></li>
                                <li><a class="dropdown-item" href="#">Something else here</a></li>
                            </ul>
                            </li> 
                            <li class="nav-item dropdown me-3">
                            <a class="nav-link dropdown-toggle" href="/" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            Service
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="#">Action</a></li>
                                <li><a class="dropdown-item" href="#">Another action</a></li>
                                <li><a class="dropdown-item" href="#">Something else here</a></li>
                            </ul>
                            </li>
                            <li className="nav-item me-3">
                                <a className="nav-link" href='/'>Domain</a>
                            </li> 
                            <li className="nav-item me-3">
                                <a className="nav-link" href='/'>About</a>
                            </li>
                        </ul>
                       

                       <button className='nav-button'>Contact Us</button>
                    </div>
                </div>
            </nav>


        </>
    )
}

export default Header