import './App.css';
import Header from './components/Header/Header';
import inlineLogo from './img/inline-logo.png'
import videothumbnil from './img/hero-images.png'
import reviewbadge1 from './img/review-badge/Rectangle 5.png'
import reviewbadge2 from './img/review-badge/Rectangle 6.png'
import reviewbadge3 from './img/review-badge/Rectangle 7.png'
// Logos
import forbes from './img/company-frame.png'
import frame18 from './img/Frame 18.png'
import frame19 from './img/Frame 19.png'
import frame20 from './img/Frame 20.png'
import frame21 from './img/Frame 21.png'
import frame22 from './img/Frame 22.png'

// hero-buttom-image
import imageframebefore from './img/hero-button-before.png';
import imageframebuttom from './img/hero-bottom-picture.png';


// section-title-logo
import servicelogo from './img/carbon_service-id.png'
import growthlogo from './img/growth.png'

import taget from './img/target.png'
import chat from './img/chat.png'
import doller from './img/doller.png'
import settings from './img/settings.png'
import select from './img/select.png'


import Footer from './components/Footer/Footer';


function App() {
  return (
    <>
      <main className='main'>
        <section className="hero">
          <Header />
          <div className="container mt-5">
            <div className="row">
              <div className="col-lg-8">
                <img src={inlineLogo} className="inline-hero-logo" alt="codelogicX" />
                <h1 className='mt-4'>Product Engineering </h1>
                <div className="d-flex justify-content-between align-items-center">
                  <button>Get Started</button>
                  <h3>Company</h3>
                </div>
              </div>
              <div className="col-lg-4">
                <img src={videothumbnil} className='video-thumbnil' alt="video-thumbnil" />


                <div className="review-badge">
                  <img src={reviewbadge1} className='reviewbadge1' alt="reviewbadge1" />
                  <img src={reviewbadge2} className='reviewbadge2' alt="reviewbadge2" />
                  <img src={reviewbadge3} className='reviewbadge3' alt="reviewbadge3" />
                  <span>Excellent 100+ Reviews</span>
                </div>
              </div>
            </div>
          </div>
          <div className="row  align-items-end">
            <div className="col-lg-4">
              <div className="image-frame-section">
                <img src={imageframebefore} className='image-hero-frame-before' alt="imageframebutto" />
                <img src={imageframebuttom} className='image-hero-frame' alt="imageframebutto" />
              </div>

            </div>
            <div className="col-lg-8">
              <div className="company-logo-cards">
                <div className="image-frame">
                  <img src={forbes} alt="forbes" />
                </div>
                <div className="image-frame">
                  <img src={frame18} alt="frame18" />
                </div>
                <div className="image-frame">
                  <img src={frame19} alt="frame19" />
                </div>
                <div className="image-frame">
                  <img src={frame20} alt="frame20" />
                </div>
                <div className="image-frame">
                  <img src={frame21} alt="frame21" />
                </div>
                <div className="image-frame">
                  <img src={frame22} alt="frame22" />
                </div>
              </div>
            </div>
          </div>
        </section>
        <section className='service'>
          <div className="section-title">
            <span className='me-5'>Service We offer</span>
            <img src={servicelogo} alt="carbon_service-id" />
          </div>
          <div className="container">
            <div className="row g-5">
              <div className="col-lg-6">
                <div class="accordion mt-5 pt-5" id="accordionExample">
                  <div class="accordion-item">
                    <h2 class="accordion-header">
                      <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                        Product development
                      </button>
                    </h2>
                    <div id="collapseOne" class="accordion-collapse collapse show" data-bs-parent="#accordionExample">
                      <div class="accordion-body">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Aperiam, cupiditate vitae quia a nisi corporis quisquam fugiat, temporibus ad debitis quo sit facilis quod ducimus possimus doloribus nostrum id sequi!
                      </div>
                    </div>
                  </div>
                  <div class="accordion-item">
                    <h2 class="accordion-header">
                      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                        Project management
                      </button>
                    </h2>
                    <div id="collapseTwo" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                      <div class="accordion-body">
                        Lorem, ipsum dolor sit amet consectetur adipisicing elit. Atque consectetur neque temporibus delectus illum provident dicta quibusdam alias veritatis nam minus, iure distinctio ipsum quasi omnis pariatur a. Vitae, dolor.
                      </div>
                    </div>
                  </div>
                  <div class="accordion-item">
                    <h2 class="accordion-header">
                      <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                        Startup consulting
                      </button>
                    </h2>
                    <div id="collapseThree" class="accordion-collapse collapse" data-bs-parent="#accordionExample">
                      <div class="accordion-body">
                        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Dolorem tempora mollitia doloribus? Tempore, culpa suscipit maiores perferendis dolore accusantium soluta non sunt, cum consequatur impedit necessitatibus sint facilis laudantium? Corporis.
                      </div>
                    </div>
                  </div>
                </div>

              </div>
              <div className="col-lg-6">
                <div className="area-title mt-5">
                  <h3>Product</h3>
                  <h3>Development</h3>
                </div>
                <div className="image-frame-section">
                  <img src={imageframebefore} className='image-hero-frame-before' alt="imageframebutto" />
                  <img src={imageframebuttom} className='image-hero-frame' alt="imageframebutto" />
                </div>
              </div>
            </div>
          </div>
        </section>
        <section className='growth'>
          <div className="section-title">
            <img src={growthlogo} alt="carbon_service-id" />
            <span className='me-5'>Journey of our Growth</span>
          </div>

          <div className="container">
            <div className="content-area-growth">
            <div className="row justify-content-center">
            <div className="col-lg-4">
              <div className="growth-card">
                <img src={taget} alt="taget" />
                <h3>CONCEPT</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quasi exercitationem quidem ipsum voluptatum autem est eos error praesentium. Assumenda eos alias animi, ipsum fugiat rerum accusamus nostrum praesentium ullam quaerat!</p>
              </div>
            </div>
            <div className="col-lg-4">
              <div className="growth-card">
                <img src={chat} alt="taget" />
                <h3>COMMUNICATION</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quasi exercitationem quidem ipsum voluptatum autem est eos error praesentium. Assumenda eos alias animi, ipsum fugiat rerum accusamus nostrum praesentium ullam quaerat!</p>
              </div>
            </div>
            <div className="col-lg-4">
              <div className="growth-card">
                <img src={doller} alt="taget" />
                <h3>BUDGET</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quasi exercitationem quidem ipsum voluptatum autem est eos error praesentium. Assumenda eos alias animi, ipsum fugiat rerum accusamus nostrum praesentium ullam quaerat!</p>
              </div>
            </div>
            <div className="col-lg-4">
              <div className="growth-card">
                <img src={settings} alt="taget" />
                <h3>DEVELOPMENT</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quasi exercitationem quidem ipsum voluptatum autem est eos error praesentium. Assumenda eos alias animi, ipsum fugiat rerum accusamus nostrum praesentium ullam quaerat!</p>
              </div>
            </div>
            <div className="col-lg-4">
              <div className="growth-card">
                <img src={select} alt="taget" />
                <h3>RESULTS</h3>
                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quasi exercitationem quidem ipsum voluptatum autem est eos error praesentium. Assumenda eos alias animi, ipsum fugiat rerum accusamus nostrum praesentium ullam quaerat!</p>
              </div>
            </div>  
          </div>
            </div>
          </div>
        </section>
        <section className='stats'>
          <div className="container">
            <div className="row g-0 align-items-center">
              <div className="col-lg-2 column-stats">
                <span>7+</span>
                <p>Years in business</p>
              </div>
              <div className="col-lg-2 column-stats">
                <span>140+</span>
                <p>Strong team</p>
              </div>
              <div className="col-lg-2 column-stats">
                <span>4</span>
                <p>Clients across continents</p>
              </div> 
              <div className="col-lg-2 column-stats">
                <span>1 million+</span>
                <p>People use our product daily</p>
              </div>    
              <div className="col-lg-2 column-stats">
                <span>90%</span>
                <p>Repeat clients</p>
              </div> 
              <div className="col-lg-2 column-stats">
                <span>6+</span>
                <p>Years longest relationship with client</p>
              </div>
            </div>
          </div>
        </section>
        <Footer />
      </main>
    </>
  );
}

export default App;
