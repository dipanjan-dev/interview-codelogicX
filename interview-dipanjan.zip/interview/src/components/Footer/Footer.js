import React from 'react'
import './Footer.css'


import Indiaflag from '../../img/openmoji_flag-india.png'
import mail from '../../img/ic_baseline-mail.png'
import call from '../../img/ion_call.png'

function Footer() {
  return (
    <>
        <footer>
            <div className="container">
                <div className="row">
                    <div className="col-lg-6">
                        <h3>Contact Information</h3>
                        <h5>address</h5>
                        <div className="d-flex align-items-start">
                            <img src={Indiaflag} alt="" />
                            <p>6th floor, WEBEL IT PARK Tower II, <br />
                            BN-9, BN Block, Sector V, Bidhannagar, <br />
                            Kolkata, West Bengal 700091</p>
                          
                        </div>
                        <div className="row">
                                <div className="col-lg-6">
                                    <div className="d-flex align-items-start">
                                        <img src={mail} alt="" className='mt-2' />
                                        <div className="data">
                                        <h5 className='mb-0'>Email</h5>
                                        <a href='mailto:hr@codelogicx.in'>hr@codelogicx.in</a>
                                        </div>
                                    </div>
                                </div>
                                <div className="col-lg-6">
                                    <div className="d-flex align-items-start">
                                        <img src={call} alt="" className='mt-2'/>
                                        <div className="data">
                                        <h5 className='mb-0'>phone</h5>
                                        <ul>
                                            <li>
                                            <a href="tel:+91-3340054624">+91-3340054624</a>
                                            </li>
                                            <li> <a href="tel:+91-6290828707">+91-6290828707</a></li>
                                        </ul>
                                        </div>
                                    </div>
                                  
                                </div>
                            </div>
                    </div>
                    <div className="col-lg-3">
                            <h2>About</h2>
                            <ul className='mt-4'>
                                <li className='mb-2'>Our Story</li>
                                <li className='mb-2'>Career</li>
                                <li className='mb-2'>Life at Codeloqicx</li>
                                <li className='mb-2'>Blog</li>
                            </ul>

                    </div>
                    <div className="col-lg-3">
                        <h2>Domains</h2>
                        <ul className='mt-4'>
                            <li className='mb-2'>Fintech</li>
                            <li className='mb-2'>Healthcare</li>
                            <li className='mb-2'>Travel & Tourism</li>
                            <li className='mb-2'>HR & Payroll</li>
                            <li className='mb-2'>Manufacturing</li>
                        </ul>
                    </div>
                </div>
            </div>
        </footer>
    </>
  )
}

export default Footer